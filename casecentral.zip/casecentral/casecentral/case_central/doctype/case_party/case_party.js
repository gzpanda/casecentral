// Copyright (c) 2023, 4C Solutions and contributors
// For license information, please see license.txt

frappe.ui.form.on('Case Party', {
    // Triggers when the 'governance' field changes
    governance: function(frm) {
        // Clear district if governance is cleared
        if (!frm.doc.governance) {
            frm.set_value('district', '');
        }
        
        // Refresh the field to apply new filters
        frm.refresh_field('district');
    },
    
    // Set the filter on district based on governance value
    before_save: function(frm) {
        set_district_filter(frm);
    },
    refresh: function(frm) {
        set_district_filter(frm);
    }
});

// Helper function to apply the filter
function set_district_filter(frm) {
    frm.set_query('district', function() {
        return {
            filters: {
                'governance': frm.doc.governance // 'governance_parent' is the fieldname in District Doctype
            }

