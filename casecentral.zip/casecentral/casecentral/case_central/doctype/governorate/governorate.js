// Copyright (c) 2026, 4C Solutions and contributors
// For license information, please see license.txt

// frappe.ui.form.on("Governorate", {
// 	refresh(frm) {

// 	},
// });
